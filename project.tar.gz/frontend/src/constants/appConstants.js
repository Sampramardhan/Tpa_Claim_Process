export const USER_ROLES = Object.freeze({
  CUSTOMER: 'CUSTOMER',
  CLIENT: 'CLIENT',
  FMG: 'FMG',
  CARRIER: 'CARRIER',
});

export const AUTH_STORAGE_KEY = 'tpa.auth.session';

export const ROLE_HOME_PATHS = Object.freeze({
  [USER_ROLES.CUSTOMER]: '/customer',
  [USER_ROLES.CLIENT]: '/client',
  [USER_ROLES.FMG]: '/fmg',
  [USER_ROLES.CARRIER]: '/carrier',
});

export const CLAIM_STATUSES = Object.freeze({
  SUBMITTED: 'SUBMITTED',
  UNDER_REVIEW: 'UNDER_REVIEW',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  MANUAL_REVIEW: 'MANUAL_REVIEW',
  PAID: 'PAID',
});

export const CLAIM_STAGES = Object.freeze({
  DRAFT: 'DRAFT',
  CUSTOMER: 'CUSTOMER',
  CUSTOMER_SUBMITTED: 'CUSTOMER_SUBMITTED',
  CLIENT_REVIEW: 'CLIENT_REVIEW',
  CLIENT_REJECTED: 'CLIENT_REJECTED',
  CLIENT: 'CLIENT',
  FMG_REVIEW: 'FMG_REVIEW',
  FMG: 'FMG',
  CARRIER: 'CARRIER',
  COMPLETED: 'COMPLETED',
});

export const POLICY_TYPES = Object.freeze({
  HEALTH: 'HEALTH',
  LIFE: 'LIFE',
  AD_AND_D: 'AD_AND_D',
  CRITICAL_ILLNESS: 'CRITICAL_ILLNESS',
});
